# -*- coding: utf-8 -*-
import os, inspect, clr
clr.AddReference('PresentationFramework')
clr.AddReference('PresentationCore')
clr.AddReference('WindowsBase')
clr.AddReference('System')

from System.Collections.Generic import List
from System.IO import Directory
from System.Windows import Window
from System.Windows.Threading import DispatcherPriority
from System import Action

from pyrevit.framework import wpf
from pyrevit import revit, DB, forms

SCRIPT_DIR = os.path.dirname(inspect.getfile(inspect.currentframe()))
XAML_PATH  = os.path.join(SCRIPT_DIR, 'ui.xaml')

# --------------------- helpers ---------------------
class ParamSetting:
    def __init__(self, name, param_obj, min_val=0, max_val=100):
        self.Name = name
        self.ParamObj = param_obj
        self.MinValue = str(min_val)
        self.MaxValue = str(max_val)

def get_all_family_instances():
    return list(DB.FilteredElementCollector(revit.doc).OfClass(DB.FamilyInstance))

def get_numeric_params(elem):
    return [p for p in elem.Parameters
            if p.StorageType == DB.StorageType.Double and not p.IsReadOnly]

def export_frame(doc, view, folder, idx):
    opts = DB.ImageExportOptions()
    opts.ExportRange = DB.ExportRange.VisibleRegionOfCurrentView
    opts.FilePath = os.path.join(folder, 'frame_{:03d}.png'.format(idx))
    opts.ImageResolution = DB.ImageResolution.DPI_600
    opts.PixelSize = 2048
    opts.FitDirection = DB.FitDirectionType.Horizontal
    opts.ShadowViewsFileType = DB.ImageFileType.PNG
    doc.ExportImage(opts)

def _safe(txt, fn):
    try: return fn(txt)
    except: return None

# ----------------------- UI ------------------------
class ParamUI(Window):
    def __init__(self):
        wpf.LoadComponent(self, XAML_PATH)
        self.instances = get_all_family_instances()
        self.familyBox.ItemsSource = [
            "{} #{}".format(i.Symbol.Family.Name, i.Id) for i in self.instances
        ]
        self.param_settings = []  # Список настроек параметров
        self.paramSettingsList.ItemsSource = self.param_settings

    def OnFamilyChanged(self, *_):
        if self.familyBox.SelectedIndex < 0: return
        self.update_params()

    def OnInstanceToggle(self, *_):
        self.update_params()

    def update_params(self):
        idx = self.familyBox.SelectedIndex
        if idx < 0: return
        inst = self.instances[idx]
        if self.instanceBox.IsChecked:
            self.par_objs = get_numeric_params(inst)
        else:
            self.par_objs = get_numeric_params(inst.Symbol)
        
        # Обновляем выпадающий список параметров
        param_names = [p.Definition.Name for p in self.par_objs]
        self.paramComboBox.ItemsSource = param_names
        if param_names:
            self.paramComboBox.SelectedIndex = 0

    def OnAddParameter(self, *_):
        """Добавляет выбранный параметр в список настроек"""
        if self.paramComboBox.SelectedIndex < 0:
            forms.alert(u'Выберите параметр для добавления')
            return
        
        param_name = self.paramComboBox.SelectedItem
        param_obj = self.par_objs[self.paramComboBox.SelectedIndex]
        
        # Проверяем, не добавлен ли уже этот параметр
        for setting in self.param_settings:
            if setting.Name == param_name:
                forms.alert(u'Параметр "{}" уже добавлен'.format(param_name))
                return
        
        # Добавляем новый параметр
        param_setting = ParamSetting(
            name=param_name,
            param_obj=param_obj,
            min_val=0,
            max_val=100
        )
        self.param_settings.append(param_setting)
        self.paramSettingsList.ItemsSource = None
        self.paramSettingsList.ItemsSource = self.param_settings
        print("Добавлен параметр: {}".format(param_name))

    def OnRemoveParameter(self, sender, *_):
        """Удаляет параметр из списка настроек"""
        param_setting = sender.Tag
        if param_setting in self.param_settings:
            self.param_settings.remove(param_setting)
            self.paramSettingsList.ItemsSource = None
            self.paramSettingsList.ItemsSource = self.param_settings
            print("Удален параметр: {}".format(param_setting.Name))

    def OnBrowse(self, *_):
        try:
            from System.Windows.Forms import FolderBrowserDialog, DialogResult
            dlg = FolderBrowserDialog()
            dlg.Description = "Выберите папку для сохранения файлов"
            
            if dlg.ShowDialog() == DialogResult.OK:
                path = dlg.SelectedPath
                print("Диалог вернул путь: {}".format(path))
                
                # Небольшая задержка для завершения диалога
                import time
                time.sleep(0.1)
                
                # Пробуем прямой способ обновления
                self.folderBox.Text = path
                print("Прямое обновление, текущее значение: {}".format(self.folderBox.Text))
                
                # Если прямой способ не сработал, используем диспетчер
                if self.folderBox.Text != path:
                    print("Прямое обновление не сработало, используем диспетчер")
                    def update_text():
                        print("Обновляем текстовое поле через диспетчер на: {}".format(path))
                        self.folderBox.Text = path
                        # Принудительно обновляем отображение
                        self.folderBox.UpdateLayout()
                        print("Текстовое поле обновлено через диспетчер, текущее значение: {}".format(self.folderBox.Text))
                    
                    # Используем диспетчер для обновления UI
                    self.Dispatcher.Invoke(Action(update_text), DispatcherPriority.Normal)
                
                print("Выбрана папка: {}".format(path))
        except Exception as e:
            print("Ошибка при выборе папки: {}".format(e))
            forms.alert(u'Ошибка при выборе папки: {}'.format(e))

    def OnCancel(self, *_):
        self.Close()

    def OnProceed(self, *_):
        try:
            print("Proceed clicked")
            print("Начинаем проверки...")
            
            # Проверка выбора семейства
            print("Проверяем выбор семейства: SelectedIndex = {}".format(self.familyBox.SelectedIndex))
            if self.familyBox.SelectedIndex < 0:
                print("Ошибка: не выбрано семейство")
                forms.alert(u'Выберите семейство'); return
            print("Семейство выбрано ✓")
            
            # Проверка выбора параметров
            print("Проверяем выбор параметров...")
            if not self.param_settings:
                print("Ошибка: не выбраны параметры")
                forms.alert(u'Добавьте хотя бы один параметр'); return
            print("Параметры выбраны ✓")

            # Парсинг значений
            print("Парсим значения из полей...")
            print("framesBox.Text = '{}'".format(self.framesBox.Text))
            print("folderBox.Text = '{}'".format(self.folderBox.Text))
            
            frames = _safe(self.framesBox.Text, int)
            folder = self.folderBox.Text

            print("Парсинг значений: frames={}, folder='{}'".format(frames, folder))

            # Проверка корректности значений
            print("Проверяем корректность значений...")
            if frames is None or frames < 2:
                print("Ошибка: неверное количество кадров")
                forms.alert(u'Неверное количество кадров'); return
            print("Количество кадров корректно ✓")
            
            if not folder or not folder.strip():
                print("Ошибка: не выбрана папка")
                forms.alert(u'Выберите папку для сохранения'); return
            print("Папка указана ✓")
                
            if not Directory.Exists(folder):
                print("Ошибка: папка не найдена: {}".format(folder))
                forms.alert(u'Папка не найдена'); return
            print("Папка существует ✓")

            # Проверка настроек параметров
            print("Проверяем настройки параметров...")
            for param_setting in self.param_settings:
                min_val = _safe(param_setting.MinValue, float)
                max_val = _safe(param_setting.MaxValue, float)
                if min_val is None or max_val is None or min_val == max_val:
                    print("Ошибка: неверные значения для параметра {}".format(param_setting.Name))
                    forms.alert(u'Неверные значения для параметра {}'.format(param_setting.Name)); return
            print("Настройки параметров корректны ✓")

            print("Все проверки пройдены, сохраняем данные...")
            
            self.sel_inst = self.instances[self.familyBox.SelectedIndex]
            self.is_instance = self.instanceBox.IsChecked
            self.sel_param_settings = self.param_settings
            self.frames, self.folder = frames, folder
            
            print("Данные сохранены: instance={}, params={}, frames={}, folder={}".format(
                self.sel_inst.Id, len(self.sel_param_settings), self.frames, self.folder))
            
            print("Устанавливаем DialogResult = True")
            self.DialogResult = True
            print("Закрываем окно")
            self.Close()
            print("Окно закрыто")
            
        except Exception as e:
            print("КРИТИЧЕСКАЯ ОШИБКА в OnProceed: {}".format(e))
            import traceback
            print("Traceback:")
            print(traceback.format_exc())
            forms.alert(u'Критическая ошибка: {}'.format(e))

# --------------------- main ------------------------
def animate():
    try:
        print("Запуск функции animate()")
        ui = ParamUI()
        print("UI создан, показываем диалог...")
        
        if not ui.ShowDialog(): 
            print("Диалог отменен пользователем")
            return

        print("Диалог подтвержден, начинаем анимацию...")
        doc, view = revit.doc, revit.doc.ActiveView
        
        print("Параметры анимации: frames={}, params={}".format(
            ui.frames, len(ui.sel_param_settings)))

        for i in range(ui.frames):
            print("Обработка кадра {}/{}".format(i+1, ui.frames))
            
            # Транзакция для изменения параметров
            with revit.Transaction('Animate params'):
                if ui.is_instance:
                    elem = doc.GetElement(ui.sel_inst.Id)
                else:
                    elem = doc.GetElement(ui.sel_inst.Symbol.Id)
                
                # Изменяем каждый параметр согласно его настройкам
                for param_setting in ui.sel_param_settings:
                    min_val = float(param_setting.MinValue)
                    max_val = float(param_setting.MaxValue)
                    step = (max_val - min_val) / float(ui.frames - 1)
                    val = min_val + i * step
                    
                    print("Устанавливаем параметр {} в значение: {}".format(param_setting.Name, val))
                    
                    pp = elem.LookupParameter(param_setting.Name)
                    if pp:
                        try:
                            # Попробуем новый API (Revit 2022+)
                            pp.Set(DB.UnitUtils.ConvertToInternalUnits(val, pp.GetUnitTypeId()))
                            print("Параметр {} установлен в {} (новый API)".format(param_setting.Name, val))
                        except:
                            try:
                                # Попробуем старый API (до Revit 2022)
                                pp.Set(DB.UnitUtils.ConvertToInternalUnits(val, pp.DisplayUnitType))
                                print("Параметр {} установлен в {} (старый API)".format(param_setting.Name, val))
                            except Exception as e:
                                # Если не удается конвертировать, устанавливаем напрямую
                                pp.Set(val)
                                print("Параметр {} установлен в {} (напрямую)".format(param_setting.Name, val))
            
            # Обновляем активный вид вместо регенерации
            try:
                doc.RefreshActiveView()
                print("Вид обновлен")
            except:
                print("Пропускаем обновление вида")
            
            print("Экспорт кадра {} в папку {}".format(i, ui.folder))
            export_frame(doc, view, ui.folder, i)

        print("Анимация завершена!")
        forms.alert(u'Готово! Создано кадров: {}'.format(ui.frames))
        
    except Exception as e:
        print("КРИТИЧЕСКАЯ ОШИБКА в animate(): {}".format(e))
        import traceback
        print("Traceback:")
        print(traceback.format_exc())
        forms.alert(u'Критическая ошибка в анимации: {}'.format(e))

if __name__ == '__main__':
    animate()
